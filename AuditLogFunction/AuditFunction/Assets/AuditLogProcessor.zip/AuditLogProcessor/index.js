"use strict";

var request = require('request');

module.exports = function (context, myEventHubTrigger) {

    context.log('======================================================');
    context.log('Node.js eventhub trigger function processed work item');

    // Grab logs from the returned records object
    var logs = myEventHubTrigger.records;

    // Prepare a response
    // Multiple logs may be received, but we'll batch into one response 
    var alert = [];

    // Loop through the logs
    var counter = 0;
    logs.forEach(function (log) {

        // Only process logs that are non-informational or a new RG
        // This cuts down on chatter everytime Azure ties its shoes
        if (log.level !== 'Information' || log.operationName === 'MICROSOFT.RESOURCES/SUBSCRIPTIONS/RESOURCEGROUPS/WRITE') {

            // Build out an alert's markup
            alert.push(buildAlert(log));

        }

        // Iterate counter and check progress
        counter++;
        if (counter === logs.length) {

            context.log('Finished looping through logs');

            // Finished iterating, send batched alert
            sendAlert(context, alert);

        }

    });

};

function buildAlert(log) {

    // String build via an array
    // Using ES6 Template Literals 
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals
    var logContent = [
        `time:\t ${log.time}`,
        `tenantId:\t ${log.identity.claims["http://schemas.microsoft.com/identity/claims/tenantid"]}`,
        `operationName:\t ${log.operationName}`,
        `category:\t ${log.category}`,
        `resultType:\t ${log.resultType}`,
        `resultSignature:\t ${log.resultSignature}`,
        `identity:\t ${log.identity.claims.name} (${log.identity.claims["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn"]})`,
        `location:\t ${log.location}`,
        `resourceId: ${log.resourceId}`
    ];

    // Determine color for alert
    var color;
    switch (log.level) {
        case 'Error':
            color = 'danger';
            break;
        case 'Warning':
            color = 'warning';
            break;
        case 'Information':
            color = '#439FE0';
            break;
    }

    // Create object to return
    var formattedLog = {
        "fallback": logContent.join('\n'),
        "color": color,
        "fields": [
            {
                "title": log.level,
                "value": logContent.join('\n'),
                "short": false
            }
        ]
    };

    // Return
    return formattedLog;

}

function sendAlert(context, alert) {

    // Send alert to Slack webhook
    request.post(process.env.SLACK_WEBHOOK_URL, {
        json: {
            "username": "audit-bot",
            "icon_url": "https://pbs.twimg.com/profile_images/546024114272468993/W9gT7hZo.png",
            "attachments": alert
        }
    }, function (error) {

        if (error) {
            context.log('Error posting the message');
            context.done(error);
        }
        else {
            context.log('Successfully posted the message');
            context.done();
        }

    });

}